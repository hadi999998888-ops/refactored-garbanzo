package com.example.overlaykit;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 100;

    private SettingsStore settings;
    private TextView permissionStatus;
    private Button toggleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        settings = new SettingsStore(this);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(32), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("Extra Hub");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("Плавающее меню Extra Hub. Кнопки в нём — демо-интерфейс, никаких функций за ними нет.");
        note.setPadding(0, dp(8), 0, dp(16));
        root.addView(note);

        permissionStatus = new TextView(this);
        root.addView(permissionStatus);

        Button grant = new Button(this);
        grant.setText("Выдать разрешение «Поверх других приложений»");
        grant.setOnClickListener(v -> openOverlayPermissionScreen());
        root.addView(grant);

        TextView opacityLabel = new TextView(this);
        opacityLabel.setText("Прозрачность панели: " + settings.getOpacityPercent() + "%");
        opacityLabel.setPadding(0, dp(20), 0, 0);
        root.addView(opacityLabel);

        SeekBar opacity = new SeekBar(this);
        opacity.setMax(80); // 20..100
        opacity.setProgress(settings.getOpacityPercent() - 20);
        opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int value = progress + 20;
                opacityLabel.setText("Прозрачность панели: " + value + "%");
                if (fromUser) settings.setOpacityPercent(value);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(opacity);

        CheckBox remember = new CheckBox(this);
        remember.setText("Запоминать положение панели");
        remember.setChecked(settings.isRememberPosition());
        remember.setOnCheckedChangeListener((b, checked) -> settings.setRememberPosition(checked));
        root.addView(remember);

        toggleButton = new Button(this);
        toggleButton.setOnClickListener(v -> toggleOverlay());
        root.addView(toggleButton);

        TextView hint = new TextView(this);
        hint.setText("Изменение прозрачности применяется при следующем запуске панели.");
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        hint.setPadding(0, dp(12), 0, 0);
        root.addView(hint);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private void refreshState() {
        boolean granted = Settings.canDrawOverlays(this);
        permissionStatus.setText(granted
                ? "Разрешение выдано"
                : "Разрешение «Поверх других приложений» не выдано");
        if (!granted) settings.setOverlayEnabled(false);
        toggleButton.setText(settings.isOverlayEnabled() ? "Остановить панель" : "Запустить панель");
    }

    private void openOverlayPermissionScreen() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void toggleOverlay() {
        if (settings.isOverlayEnabled()) {
            Intent stop = new Intent(this, OverlayService.class);
            stop.setAction(OverlayService.ACTION_STOP);
            startService(stop);
            settings.setOverlayEnabled(false);
            refreshState();
            return;
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала выдайте разрешение", Toast.LENGTH_SHORT).show();
            openOverlayPermissionScreen();
            return;
        }

        // На Android 13+ без разрешения на уведомления панель всё равно работает,
        // но уведомление службы не будет видно, поэтому просим его заранее.
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        startOverlay();
    }

    private void startOverlay() {
        Intent start = new Intent(this, OverlayService.class);
        start.setAction(OverlayService.ACTION_START);
        startForegroundService(start);
        settings.setOverlayEnabled(true);
        refreshState();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) {
            // Запускаем в любом случае: отказ влияет только на видимость уведомления.
            startOverlay();
        }
    }
}
