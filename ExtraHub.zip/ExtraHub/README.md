# OverlayKit

Минимальное Android-приложение с плавающей панелью поверх других приложений.

- Android SDK, без внешних зависимостей, Java 17
- compileSdk/targetSdk 34 (Android 14), minSdk 26
- Разрешение SYSTEM_ALERT_WINDOW запрашивается через системный экран настроек
- Настройки (прозрачность, запоминание позиции, состояние) хранятся в SharedPreferences
- Службе на Android 14 задан foregroundServiceType="specialUse" и нужные разрешения

## Чего здесь нет

Нет ESP, Box ESP, Wall ESP и любого обнаружения игроков. Такие функции требуют
реального источника игровых данных, которого у приложения нет, поэтому они не
заявлены и не имитируются. Панель показывает честный статус
«Источник игровых данных не подключён».

## Сборка

Нужны JDK 17+ и Android SDK (platform 34, build-tools 34.x).

```
echo "sdk.dir=/путь/к/Android/Sdk" > local.properties
gradle wrapper --gradle-version 8.9      # один раз, создаст gradlew
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

Либо откройте папку в Android Studio и нажмите Build > Build APK(s).
