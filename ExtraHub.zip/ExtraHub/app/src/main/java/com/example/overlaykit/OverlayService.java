package com.example.overlaykit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Показывает перетаскиваемую панель поверх других приложений.
 * Панель содержит только статус и кнопку закрытия: никаких данных
 * сторонних игр сервис не читает и ничего поверх них не рисует.
 */
public class OverlayService extends Service {
    public static final String ACTION_START = "com.example.overlaykit.START";
    public static final String ACTION_STOP = "com.example.overlaykit.STOP";
    private static final String CHANNEL_ID = "overlay_channel";
    private static final int NOTIF_ID = 1;

    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private SettingsStore settings;

    @Override
    public void onCreate() {
        super.onCreate();
        settings = new SettingsStore(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelfAndCleanup();
            return START_NOT_STICKY;
        }

        // Без разрешения окно добавить нельзя: останавливаемся без падения.
        if (!Settings.canDrawOverlays(this)) {
            settings.setOverlayEnabled(false);
            stopSelf();
            return START_NOT_STICKY;
        }

        startInForeground();
        if (panel == null) {
            addPanel();
        }
        settings.setOverlayEnabled(true);
        return START_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Оверлей", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(channel);

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Extra Hub активен")
                .setContentText("Нажмите, чтобы открыть настройки")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView makeButton(String label) {
        final TextView b = new TextView(this);
        b.setText(label + "   ВЫКЛ");
        b.setTextColor(Color.parseColor("#BDC1C6"));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#33FFFFFF"));
        bg.setCornerRadius(dp(8));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                dp(190), LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    /** Кнопка-переключатель: только меняет вид, никакой функции за ней нет. */
    private void addToggle(LinearLayout root, final String label) {
        final TextView b = makeButton(label);
        final boolean[] on = {false};
        b.setOnClickListener(v -> {
            on[0] = !on[0];
            b.setText(label + (on[0] ? "   ВКЛ" : "   ВЫКЛ"));
            b.setTextColor(Color.parseColor(on[0] ? "#81C995" : "#BDC1C6"));
        });
        root.addView(b);
    }

    private void addPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#E6202124"));
        bg.setCornerRadius(dp(12));
        root.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Extra Hub");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        addToggle(root, "ESP");
        addToggle(root, "Wallhack");
        addToggle(root, "Aim");
        addToggle(root, "Air Jump");

        TextView settingsBtn = makeButton("Настройки");
        settingsBtn.setText("Настройки");
        settingsBtn.setTextColor(Color.WHITE);
        settingsBtn.setOnClickListener(v -> {
            Intent open = new Intent(this, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(open);
        });
        root.addView(settingsBtn);

        TextView note = new TextView(this);
        note.setText("Демо-интерфейс: функции не подключены");
        note.setTextColor(Color.parseColor("#80868B"));
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        note.setPadding(0, dp(8), 0, 0);
        root.addView(note);

        TextView close = new TextView(this);
        close.setText("Закрыть");
        close.setTextColor(Color.parseColor("#8AB4F8"));
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        close.setPadding(0, dp(8), 0, dp(4));
        close.setOnClickListener(v -> stopSelfAndCleanup());
        root.addView(close);

        root.setAlpha(settings.getOpacityPercent() / 100f);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        if (settings.isRememberPosition()) {
            params.x = settings.getX();
            params.y = settings.getY();
        } else {
            params.x = 40;
            params.y = 200;
        }

        root.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int) (e.getRawX() - touchX);
                        params.y = startY + (int) (e.getRawY() - touchY);
                        windowManager.updateViewLayout(panel, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (settings.isRememberPosition()) {
                            settings.setPosition(params.x, params.y);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        panel = root;
        try {
            windowManager.addView(panel, params);
        } catch (RuntimeException ex) {
            // Например, разрешение отозвано между проверкой и добавлением окна.
            panel = null;
            settings.setOverlayEnabled(false);
            stopSelf();
        }
    }

    private void stopSelfAndCleanup() {
        removePanel();
        settings.setOverlayEnabled(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void removePanel() {
        if (panel != null) {
            try {
                windowManager.removeView(panel);
            } catch (IllegalArgumentException ignored) {
                // окно уже удалено
            }
            panel = null;
        }
    }

    @Override
    public void onDestroy() {
        removePanel();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
